BIG BULL COPY V4 - Demo-only local web prototype

1. Close the previous BIG BULL connector CMD window (Ctrl+C). Keep MT5 Demo terminal running.
2. Extract this ZIP to a NEW folder. Do not run start.bat inside the ZIP.
3. Double-click start.bat. Open http://127.0.0.1:8765/?v=4 in Chrome.
4. CLIENT PANEL: enter client name, MT5 demo account number, demo broker server, fixed lot and consent. Click Send Approval Request. No trading password required.
5. ADMIN: open admin_key.txt (automatically created at first startup) and paste its contents into Admin Approval tab. Click Load Requests, then Approve or Reject.
6. CLIENT PANEL: click Refresh My Status and see the result.

IMPORTANT: Approved means AWAITING MT5 CONNECTION, NOT ACTIVE COPYING. This prototype does not log in to client terminals, does not connect real clients, does not place trades, and does not send or store MT5 trading passwords.

MASTER READ ONLY: connects to your already-open Demo MT5 account and reads XAUUSD.p price, balance, positions and pending orders. Change symbol before launch by setting BIG_BULL_SYMBOL if required.

SECURITY: Local testing only. HTTP service listens exclusively on 127.0.0.1. Admin key is local; do NOT share, upload online, or expose port 8765 to internet. Do not put confidential trading passwords anywhere in this demo.

Troubleshooting: If old page appears, close old CMD and run V4 start.bat; press Ctrl+F5 in Chrome. If port 8765 is occupied, close old server. Account requests are saved in clients_v4.json. Client status token is kept only for the current browser tab/session.
