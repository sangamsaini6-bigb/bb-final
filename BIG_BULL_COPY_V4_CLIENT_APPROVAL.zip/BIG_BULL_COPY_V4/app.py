"""BIG BULL COPY V4 - local demo registration & approval; MT5 master READ ONLY."""
import json, os, secrets, threading, time
from pathlib import Path
from contextlib import asynccontextmanager
from uuid import uuid4
from fastapi import FastAPI, HTTPException, Header
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field
import MetaTrader5 as mt5

ROOT = Path(__file__).resolve().parent
DB=ROOT/'clients_v4.json'
ADMIN_FILE=ROOT/'admin_key.txt'
LOCK=threading.RLock()
SYMBOL=os.environ.get('BIG_BULL_SYMBOL','XAUUSD.p')
if not ADMIN_FILE.exists():
    ADMIN_FILE.write_text(secrets.token_urlsafe(30),encoding='utf-8')
ADMIN_KEY=ADMIN_FILE.read_text(encoding='utf-8').strip()

def get_rows():
    if not DB.exists(): return []
    return json.loads(DB.read_text(encoding='utf-8'))
def save_rows(rows):
    tmp=DB.with_suffix('.tmp'); tmp.write_text(json.dumps(rows,indent=2),encoding='utf-8');tmp.replace(DB)
def admin_auth(x_admin_key: str | None):
    if not x_admin_key or not secrets.compare_digest(x_admin_key, ADMIN_KEY):
        raise HTTPException(401,'Admin key required or incorrect')

def public_client(r):
    return {k:r[k] for k in ('id','label','login','server','lot','status','created_at')}

@asynccontextmanager
async def lifespan(app):
    if mt5.initialize(): mt5.symbol_select(SYMBOL,True)
    else: print('MT5 unavailable (client approval demo still works):',mt5.last_error())
    print('ADMIN KEY: open admin_key.txt in the V4 folder. Do not share it.')
    yield
    mt5.shutdown()

app=FastAPI(title='BIG BULL COPY V4 · LOCAL DEMO',docs_url=None,redoc_url=None,openapi_url=None,lifespan=lifespan)

class Registration(BaseModel):
    label: str=Field(min_length=1,max_length=45)
    login: str=Field(pattern=r'^\d{4,15}$')
    server: str=Field(min_length=3,max_length=90)
    lot: float=Field(ge=0.01,le=10.0)
    consent: bool

@app.post('/api/register',status_code=201)
def register(p:Registration):
    if not p.consent: raise HTTPException(400,'Please confirm you own/control this demo account.')
    with LOCK:
        rows=get_rows()
        if len(rows)>=25: raise HTTPException(400,'25-client demo capacity reached')
        if any(r['login']==p.login and r['server'].lower()==p.server.lower() for r in rows):raise HTTPException(409,'Account already registered')
        token=secrets.token_urlsafe(24)
        r={'id':uuid4().hex,'label':p.label.strip(),'login':p.login,'server':p.server.strip(),'lot':p.lot,'status':'PENDING_APPROVAL','created_at':time.strftime('%Y-%m-%d %H:%M:%S'),'client_token':token}
        rows.append(r);save_rows(rows)
    return {'client_token':token,'client':public_client(r),'message':'Request submitted. No MT5 account connected.'}

@app.get('/api/client/me')
def own_client(x_client_token:str|None=Header(default=None)):
    rows=get_rows()
    for r in rows:
        if x_client_token and secrets.compare_digest(x_client_token,r['client_token']):return public_client(r)
    raise HTTPException(401,'Client token missing or invalid')

@app.get('/api/admin/clients')
def admin_clients(x_admin_key:str|None=Header(default=None)):
    admin_auth(x_admin_key)
    return [public_client(r) for r in get_rows()]

@app.post('/api/admin/clients/{cid}/{action}')
def decide(cid:str,action:str,x_admin_key:str|None=Header(default=None)):
    admin_auth(x_admin_key)
    if action not in ('approve','reject','disable'):raise HTTPException(400,'Invalid action')
    with LOCK:
        rows=get_rows()
        for r in rows:
            if r['id']==cid:
                if action=='approve':
                    if r['status']!='PENDING_APPROVAL':raise HTTPException(409,'Only pending requests can be approved')
                    r['status']='APPROVED_AWAITING_MT5_CONNECTION'
                elif action=='reject':
                    if r['status']!='PENDING_APPROVAL':raise HTTPException(409,'Only pending requests can be rejected')
                    r['status']='REJECTED'
                else:r['status']='DISABLED'
                save_rows(rows)
                return {'client':public_client(r),'copying_active':False}
    raise HTTPException(404,'Client not found')

@app.get('/api/master')
def master():
    t=mt5.terminal_info();a=mt5.account_info()
    if not t or not t.connected or not a:raise HTTPException(503,'MT5 terminal not connected')
    if a.trade_mode != mt5.ACCOUNT_TRADE_MODE_DEMO:raise HTTPException(403,'Connect demo master account only')
    if not mt5.symbol_select(SYMBOL,True):raise HTTPException(404,f'Symbol {SYMBOL} unavailable')
    q=mt5.symbol_info_tick(SYMBOL)
    if q is None:raise HTTPException(503,'No quote available')
    ps=mt5.positions_get();orders=mt5.orders_get()
    if ps is None or orders is None:raise HTTPException(503,'Cannot retrieve MT5 orders')
    kinds={2:'Buy Limit',3:'Sell Limit',4:'Buy Stop',5:'Sell Stop',6:'Buy Stop Limit',7:'Sell Stop Limit'}
    return {'symbol':SYMBOL,'bid':q.bid,'ask':q.ask,'quote_time':time.strftime('%H:%M:%S',time.localtime(q.time)),'quote_age_seconds':max(0,int(time.time()-q.time)),'balance':a.balance,'equity':a.equity,'positions':[{'ticket':p.ticket,'symbol':p.symbol,'type':'BUY' if p.type==0 else 'SELL','lot':p.volume,'price':p.price_open,'sl':p.sl,'tp':p.tp} for p in ps],'pending':[{'ticket':o.ticket,'symbol':o.symbol,'type':kinds.get(o.type,str(o.type)),'lot':o.volume_current,'price':o.price_open,'sl':o.sl,'tp':o.tp} for o in orders]}

PAGE=r'''<!doctype html><html lang="hi"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>BIG BULL COPY V4</title><style>
:root{font-family:Segoe UI,Arial,sans-serif;color-scheme:dark}*{box-sizing:border-box}body{margin:0;background:#0a1221;color:#f1f5fb}main{max-width:1150px;margin:auto;padding:22px}h1{color:#f0c36e;margin:0}h2{font-size:20px}p{line-height:1.5}.sub{color:#9fb2cf}.tag{display:inline-block;padding:5px 12px;border-radius:40px;background:#233650;color:#ecca78;font-size:12px;font-weight:bold}.tabs{display:flex;gap:8px;flex-wrap:wrap;margin:22px 0}button{border:0;padding:11px 17px;border-radius:9px;background:#e9c06e;color:#182237;font-weight:700;cursor:pointer}button:disabled{opacity:.4;cursor:not-allowed}button.sec{background:#2a3f60;color:#fff}button.red{background:#65313a;color:#fff}.panel{background:#16243a;border:1px solid #304361;border-radius:17px;padding:22px;margin:14px 0}.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px}.metric{background:#213149;border-radius:13px;padding:17px}.metric .value{font-size:28px;font-weight:750;margin-top:8px}.green{color:#62e2b0}.yellow{color:#f3cc7a}.warning{padding:13px;background:#372c25;border-radius:10px;color:#f1cf88;font-size:13px}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:13px}label{display:flex;flex-direction:column;gap:7px;color:#bfcfe7;font-size:13px}input{width:100%;background:#0b182b;color:white;border:1px solid #3b526f;border-radius:9px;padding:12px;font-size:15px}input[type=checkbox]{width:auto}table{width:100%;border-collapse:collapse;font-size:13px}td,th{padding:11px;text-align:left;border-bottom:1px solid #35465f;word-break:break-word}th{color:#adc3e0}.scroll{overflow:auto}.hidden{display:none}.msg{color:#edca83;min-height:20px}.row{display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap}@media(max-width:500px){main{padding:12px}.panel{padding:14px}.metric .value{font-size:22px}}
</style></head><body><main><div class="row"><div><h1>🐂 BIG BULL COPY <span style="font-size:14px">V4</span></h1><div class="sub">Master Live MT5 • Client Self Registration • Admin Approval</div></div><span class="tag">DEMO ONLY · NO COPY EXECUTION</span></div><nav class="tabs"><button onclick="view('master')">📊 Master</button><button class="sec" onclick="view('client')">📱 Client Panel</button><button class="sec" onclick="view('admin')">🛡️ Admin Approval</button></nav><div class="warning">यह लोकल Testing Prototype है। Master MT5 केवल Read-only है। Approval से ग्राहक का MT5 Account Connect या Trade Copy नहीं होता। कोई Trading Password यहाँ मत डालें।</div>
<section id="master"><div class="panel"><h2>Master MT5 — <span id="symbol">XAUUSD.p</span></h2><p class="sub" id="masterState">Connecting...</p><div class="cards"><div class="metric">BID<div class="value green" id="bid">—</div></div><div class="metric">ASK<div class="value yellow" id="ask">—</div></div><div class="metric">Balance<div class="value" id="balance">—</div></div><div class="metric">Equity<div class="value" id="equity">—</div></div></div><p class="sub" id="quoteInfo"></p></div><div class="panel"><h2>Master Open Positions</h2><div class="scroll"><table><thead><tr><th>Ticket</th><th>Symbol</th><th>Type</th><th>Lot</th><th>Entry</th><th>SL</th><th>TP</th></tr></thead><tbody id="positions"></tbody></table></div></div><div class="panel"><h2>Master Pending Orders</h2><p class="sub">Buy/Sell Limit • Buy/Sell Stop • Buy/Sell Stop Limit (broker support dependent)</p><div class="scroll"><table><thead><tr><th>Ticket</th><th>Symbol</th><th>Type</th><th>Lot</th><th>Entry</th><th>SL</th><th>TP</th></tr></thead><tbody id="pending"></tbody></table></div></div></section>
<section id="client" class="hidden"><div class="panel"><h2>Client — Add Your Demo MT5 Account</h2><p class="sub">Client अपना Account Registration Request भेजेगा। इसमें कोई Password नहीं लिया जाता।</p><form id="reg"><div class="grid"><label>Client Name<input name="label" required maxlength="45" placeholder="Your name"></label><label>Demo MT5 Account ID<input name="login" required pattern="[0-9]{4,15}" placeholder="Numeric account number"></label><label>Broker Demo Server<input name="server" required maxlength="90" placeholder="Example-Demo"></label><label>Fixed Lot<input name="lot" required type="number" step="0.01" min="0.01" max="10" value="0.01"></label></div><p><label style="display:flex;flex-direction:row;align-items:center"><input type="checkbox" name="consent" required> यह मेरा अपना/अधिकृत Demo Account है।</label></p><button type="submit">Send Approval Request</button></form><p class="msg" id="clientMsg"></p></div><div class="panel"><h2>My Registration Status</h2><p class="sub">Request भेजने के बाद इस Browser में Token सुरक्षित रखने के लिए याद रखें; यह Prototype Browser Session तक सीमित है।</p><button class="sec" onclick="checkOwn()">Refresh My Status</button><p id="ownState" class="msg">No registration in this session.</p><p class="sub">Approved = waiting for separate MT5 connection. Copying remains OFF.</p></div></section>
<section id="admin" class="hidden"><div class="panel"><h2>Admin — Approval Dashboard</h2><p class="sub">V4 Folder की <code>admin_key.txt</code> फाइल में अपना Local Admin Key मिलेगा। यह Key Clients को न दें।</p><div class="grid"><label>Local Admin Key<input id="adminKey" type="password" autocomplete="off" placeholder="Paste from admin_key.txt"></label><div style="align-self:end"><button onclick="loadAdmin()">Load Requests</button></div></div><p class="msg" id="adminMsg"></p></div><div class="panel"><div class="row"><h2>25 Client Requests</h2><span class="tag" id="count">0 / 25</span></div><div class="scroll"><table><thead><tr><th>Client</th><th>Demo ID</th><th>Server</th><th>Lot</th><th>Status</th><th>Action</th></tr></thead><tbody id="requests"><tr><td colspan="6">Enter admin key and load requests</td></tr></tbody></table></div></div></section>
<p class="sub">Master quotes refresh every 2 seconds. Run only on your computer (127.0.0.1). Do not expose this prototype to the Internet.</p></main><script>
const $=s=>document.getElementById(s);const adminkey=()=> $('adminKey').value.trim();function view(id){for(const s of ['master','client','admin'])$(s).classList.toggle('hidden',id!==s);if(id==='admin'&&adminkey())loadAdmin()}
async function api(path,method='GET',body=null,headers={}){const r=await fetch(path,{method,headers:{...(body?{'Content-Type':'application/json'}:{}),...headers},body:body?JSON.stringify(body):undefined,cache:'no-store'});const d=await r.json();if(!r.ok)throw Error(d.detail||'Request failed');return d}
function draw(id,rows,keys){const el=$(id);el.replaceChildren();if(!rows.length){const tr=document.createElement('tr'),td=document.createElement('td');td.colSpan=keys.length;td.textContent='None';tr.append(td);el.append(tr);return}rows.forEach(row=>{const tr=document.createElement('tr');keys.forEach(k=>{const td=document.createElement('td');td.textContent=row[k]??'—';tr.append(td)});el.append(tr)})}
async function refreshMaster(){try{const d=await api('/api/master');$('symbol').textContent=d.symbol;for(const k of ['bid','ask','balance','equity'])$(k).textContent=d[k];$('masterState').textContent='● MT5 DEMO Connected (Read Only)';$('masterState').className='green';$('quoteInfo').textContent='Broker quote at '+d.quote_time+' · age '+d.quote_age_seconds+' s';draw('positions',d.positions,['ticket','symbol','type','lot','price','sl','tp']);draw('pending',d.pending,['ticket','symbol','type','lot','price','sl','tp'])}catch(e){$('masterState').textContent='MT5 unavailable: '+e.message;$('masterState').className='yellow';}}
$('reg').addEventListener('submit',async ev=>{ev.preventDefault();const f=new FormData(ev.target);try{const data={label:f.get('label'),login:f.get('login'),server:f.get('server'),lot:Number(f.get('lot')),consent:!!f.get('consent')};const d=await api('/api/register','POST',data);sessionStorage.setItem('bbClientToken',d.client_token);$('clientMsg').textContent='Request submitted! Status: Pending Admin Approval. No trade copying.';ev.target.reset();checkOwn()}catch(e){$('clientMsg').textContent=e.message}});
async function checkOwn(){try{const t=sessionStorage.getItem('bbClientToken');if(!t){$('ownState').textContent='No client token in this Browser session.';return}const d=await api('/api/client/me','GET',null,{'X-Client-Token':t});$('ownState').textContent=d.label+' · '+d.status.replaceAll('_',' ')+' · Trading Copy OFF'}catch(e){$('ownState').textContent=e.message}}
async function loadAdmin(){try{const rows=await api('/api/admin/clients','GET',null,{'X-Admin-Key':adminkey()});$('adminMsg').textContent='Registered requests loaded. Approval never starts copying.';$('count').textContent=rows.length+' / 25';const el=$('requests');el.replaceChildren();if(!rows.length){const tr=document.createElement('tr'),td=document.createElement('td');td.colSpan=6;td.textContent='No requests yet';tr.append(td);el.append(tr)}for(const c of rows){const tr=document.createElement('tr');for(const v of [c.label,c.login,c.server,c.lot,c.status.replaceAll('_',' ')]){const td=document.createElement('td');td.textContent=v;tr.append(td)}const td=document.createElement('td');for(const [label,action] of [['Approve','approve'],['Reject','reject'],['Disable','disable']]){const b=document.createElement('button');b.textContent=label;b.className=action==='approve'?'':'red';b.disabled=action!=='disable'&&c.status!=='PENDING_APPROVAL';b.style.margin='2px';b.onclick=()=>decide(c.id,action);td.append(b)}tr.append(td);el.append(tr)}}catch(e){$('adminMsg').textContent=e.message}}
async function decide(id,action){try{await api('/api/admin/clients/'+id+'/'+action,'POST',null,{'X-Admin-Key':adminkey()});loadAdmin()}catch(e){$('adminMsg').textContent=e.message}}
refreshMaster();setInterval(refreshMaster,2000);checkOwn();
</script></body></html>'''

@app.get('/',response_class=HTMLResponse)
def page():return PAGE
